import java.util.Arrays;

class BookInventorySystem {
    public boolean checkAvailability(String bookId) {
        return true;
    }

    public void borrowBook(String bookId) {
        System.out.println("Book with ID " + bookId + " has been borrowed.");
    }

    public void returnBook(String bookId) {
        System.out.println("Book with ID " + bookId + " has been returned.");
    }
}

class UserManagementSystem {
    public String[] searchBooksByTitle(String title) {
        return new String[]{"Book 1", "Book 2", "Book 3"};
    }

    public String[] searchBooksByAuthor(String author) {
        return new String[]{"Book 4", "Book 5", "Book 6"};
    }
}

class LibraryManagementFacade {
    private BookInventorySystem bookInventorySystem;
    private UserManagementSystem userManagementSystem;

    public LibraryManagementFacade() {
        this.bookInventorySystem = new BookInventorySystem();
        this.userManagementSystem = new UserManagementSystem();
    }

    public void borrowBook(String bookId) {
        if (bookInventorySystem.checkAvailability(bookId)) {
            bookInventorySystem.borrowBook(bookId);
            System.out.println("Book borrowed successfully.");
        } else {
            System.out.println("Book is not available for borrowing.");
        }
    }

    public void returnBook(String bookId) {
        bookInventorySystem.returnBook(bookId);
        System.out.println("Book returned successfully.");
    }

    public void searchBooksByTitle(String title) {
        String[] books = userManagementSystem.searchBooksByTitle(title);
        System.out.println("Books found by title: " + Arrays.toString(books));
    }

    public void searchBooksByAuthor(String author) {
        String[] books = userManagementSystem.searchBooksByAuthor(author);
        System.out.println("Books found by author: " + Arrays.toString(books));
    }
}

// Test Cases
public class Main {
    public static void main(String[] args) {
        LibraryManagementFacade libraryFacade = new LibraryManagementFacade();
        libraryFacade.borrowBook("123");
        libraryFacade.returnBook("123");
        libraryFacade.searchBooksByTitle("Harry Potter");
        libraryFacade.searchBooksByAuthor("J.K. Rowling");
    }
}