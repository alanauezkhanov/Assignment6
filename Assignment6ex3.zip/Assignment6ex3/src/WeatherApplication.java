import java.util.HashMap;
import java.util.Map;

class WeatherData {
    private String location;
    private String temperature;
    private String condition;

    public WeatherData(String location, String temperature, String condition) {
        this.location = location;
        this.temperature = temperature;
        this.condition = condition;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

}

interface WeatherAPI {
    WeatherData getWeather(String location);
}

class AccuWeatherAPI implements WeatherAPI {
    @Override
    public WeatherData getWeather(String location) {
        String temperature = "25°C";
        String condition = "Sunny";
        return new WeatherData(location, temperature, condition);
    }
}

class OpenWeatherMapAPI implements WeatherAPI {
    @Override
    public WeatherData getWeather(String location) {
        String temperature = "20°C";
        String condition = "Cloudy";
        return new WeatherData(location, temperature, condition);
    }
}

class WeatherAPIAdapter implements WeatherAPI {
    private WeatherAPI weatherAPI;

    public WeatherAPIAdapter(WeatherAPI weatherAPI) {
        this.weatherAPI = weatherAPI;
    }

    @Override
    public WeatherData getWeather(String location) {
        return weatherAPI.getWeather(location);
    }
}

// Main class
public class WeatherApplication {
    public static void main(String[] args) {
        WeatherAPI accuWeatherAPI = new AccuWeatherAPI();
        WeatherAPI openWeatherMapAPI = new OpenWeatherMapAPI();

        WeatherAPIAdapter accuWeatherAdapter = new WeatherAPIAdapter(accuWeatherAPI);
        WeatherAPIAdapter openWeatherMapAdapter = new WeatherAPIAdapter(openWeatherMapAPI);

        String location = "New York";

        WeatherData accuWeatherData = accuWeatherAdapter.getWeather(location);
        WeatherData openWeatherMapData = openWeatherMapAdapter.getWeather(location);

        System.out.println("Weather in " + location + " (AccuWeather):");
        printWeatherData(accuWeatherData);
        System.out.println();

        System.out.println("Weather in " + location + " (OpenWeatherMap):");
        printWeatherData(openWeatherMapData);
    }

    private static void printWeatherData(WeatherData weatherData) {
        System.out.println("Location: " + weatherData.getLocation());
        System.out.println("Temperature: " + weatherData.getTemperature());
        System.out.println("Condition: " + weatherData.getCondition());
    }
}
