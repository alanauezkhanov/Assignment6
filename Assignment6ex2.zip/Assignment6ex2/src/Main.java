class Pizza {
    protected double price;

    public Pizza() {
        this.price = 10.0;
    }

    public double getPrice() {
        return price;
    }
}

abstract class PizzaDecorator extends Pizza {
    protected Pizza pizza;

    public PizzaDecorator(Pizza pizza) {
        this.pizza = pizza;
    }

    public abstract double getPrice();
}

class PepperoniTopping extends PizzaDecorator {
    public PepperoniTopping(Pizza pizza) {
        super(pizza);
    }

    @Override
    public double getPrice() {
        double pepperoniPrice = 2.5;
        return pizza.getPrice() + pepperoniPrice;
    }
}

class MushroomTopping extends PizzaDecorator {
    public MushroomTopping(Pizza pizza) {
        super(pizza);
    }

    @Override
    public double getPrice() {
        double mushroomPrice = 1.8;
        return pizza.getPrice() + mushroomPrice;
    }
}

public class Main {
    public static void main(String[] args) {
        Pizza pizza = new Pizza();

        PizzaDecorator pizzaWithPepperoni = new PepperoniTopping(pizza);

        PizzaDecorator pizzaWithPepperoniAndMushroom = new MushroomTopping(pizzaWithPepperoni);

        double finalPrice = pizzaWithPepperoniAndMushroom.getPrice();

        System.out.println("Final price of the pizza: $" + finalPrice);
    }
}